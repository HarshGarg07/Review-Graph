from django.contrib import admin
from Home.models import Contact
from Home.views import Contact 

# Register your models here.
admin.site.register(Contact)
